# QR Code & Sharing - Quick Start Guide
## AI ROI Calculator - Alexander Scott and Associates

**Goal:** Get your calculator accessible to presentation audiences in 10 minutes

---

## ⚡ **Super Quick Process (3 Steps)**

### **Step 1: Publish (2 minutes)**
1. Click **"Publish"** tab at the top of Genspark
2. Click **"Deploy"** or **"Publish"** button  
3. **Copy the URL** you receive (e.g., `https://yourproject.genspark.ai`)

### **Step 2: Create QR Code (3 minutes)**
1. Go to **https://www.qr-code-generator.com/**
2. Paste your URL
3. Click **"Create QR Code"**
4. Download as **PNG (high resolution)**

### **Step 3: Add to Presentation (5 minutes)**
1. Insert QR code image into your PowerPoint/Keynote
2. Make it **large** (at least 1/4 of slide)
3. Add text: **"Scan to Calculate Your AI ROI"**
4. Test scan from 10 feet away with your phone

**DONE! Your audience can now access the calculator! 🎉**

---

## 📱 **How Audiences Will Use It**

### **On iPhone:**
1. Open regular Camera app
2. Point at QR code
3. Tap the notification that appears
4. Calculator opens in Safari - no app needed!

### **On Android:**
1. Open Camera or Google Lens
2. Point at QR code
3. Tap "Open Link" or notification
4. Calculator opens in Chrome - no app needed!

### **No QR Scanner Needed:**
- Modern phones (2018+) scan QR codes automatically
- Works with built-in camera apps
- Zero downloads required
- Zero sign-ups required
- Works instantly!

---

## 🎤 **During Presentation - Say This:**

### **Opening Script:**
```
"Take out your phones right now.

Open your camera and point it at this QR code.

Tap the notification - the calculator will open.

No app, no login, completely free.

Give me a thumbs up when you see it!"
```

### **Follow-Up:**
```
"Now let's calculate YOUR AI ROI together using YOUR numbers.

First field: How many employees?
Second field: Hours saved per day?
Third field: Average hourly wage?

Hit calculate... 

Look at that ROI! 🚀"
```

---

## 🔗 **Backup Plan: Shortened URL**

### **Create a Short Link:**
1. Go to **https://bitly.com/** (free account)
2. Paste your published URL
3. Customize it: `bit.ly/WiltsAIROI`
4. **Display on slide** as backup

### **When to Use:**
- WiFi issues
- QR code won't scan
- Someone asks for link
- Email follow-up

---

## 🎯 **Best Practices**

### **✅ DO:**
- Show QR code for **60 seconds minimum**
- Test beforehand on your phone
- Have shortened URL visible as backup
- Give audience time to scan and load
- Walk through calculation together

### **❌ DON'T:**
- Rush past QR code slide (give time!)
- Assume everyone has QR scanner app
- Skip testing before presentation
- Make QR code too small
- Forget to provide shortened URL backup

---

## 📋 **Pre-Event Checklist**

**Night Before:**
- [ ] Publish calculator (get URL)
- [ ] Create QR code
- [ ] Create shortened URL
- [ ] Add to presentation slides
- [ ] Test on your phone
- [ ] Test on friend's phone

**1 Hour Before:**
- [ ] Verify URL still works
- [ ] Test on venue WiFi
- [ ] Have backup ready
- [ ] QR code visible and large

---

## 💡 **Pro Tips**

### **Make It Memorable:**
Create custom short URL:
- ✅ `bit.ly/AlexanderScottROI`
- ✅ `tinyurl.com/ai-roi-calc`
- ❌ `bit.ly/3x8hTpQ` (too random)

### **Brand Your QR Code:**
- Add your logo in the center (QRCode Monkey)
- Use your brand colors (#2563eb blue)
- Add frame with call-to-action text

### **Follow-Up:**
- Email the link to attendees
- Post on LinkedIn with hashtag
- Add to business cards
- Include in handouts

---

## 🚨 **Troubleshooting**

### **"QR Code Won't Scan"**
- Move phone 6-12 inches away
- Ensure good lighting
- Try different angle
- **Backup:** Show shortened URL

### **"Page Won't Load"**
- Check venue WiFi
- Try cellular data
- **Your calculator is optimized for fast loading**
- Have screenshot backup in slides

### **"Doesn't Work on My Phone"**
- **Your calculator works on all phones!**
- Try opening camera app manually
- Some very old phones need QR scanner app
- **Backup:** Type in shortened URL

---

## 📊 **Expected Results**

### **Audience Engagement:**
- 80-90% will successfully scan and access
- 5-10% will need shortened URL backup
- 100% engagement when you walk through calculation together

### **Typical Timeline:**
- **0:00** - Show QR code
- **0:30** - Most people scanning
- **0:45** - 75% have it loaded
- **1:00** - Ready to start calculation demo
- **1:00-5:00** - Interactive calculation session

---

## 🎨 **QR Code Slide Template**

```
╔═══════════════════════════════════════╗
║                                       ║
║     CALCULATE YOUR AI ROI NOW         ║
║                                       ║
║         ┌─────────────┐              ║
║         │             │              ║
║         │  QR CODE    │              ║
║         │   IMAGE     │              ║
║         │             │              ║
║         └─────────────┘              ║
║                                       ║
║    📱 Scan with your phone camera     ║
║       No app download needed          ║
║                                       ║
║    Or visit: bit.ly/YourLink          ║
║                                       ║
╚═══════════════════════════════════════╝
```

---

## 📧 **Follow-Up Email Template**

```
Subject: AI ROI Calculator from [Event Name]

Hi [Name],

Great meeting you at [event]!

Here's the AI ROI Calculator we used:
👉 [Your Published URL]

Or scan the QR code: [Attach image]

Try different scenarios with your real numbers.

Questions? Let's talk:
📅 https://calendly.com/coachwiltsalexander/30min
📞 678-428-5997

Wilts Alexander
Alexander Scott and Associates
```

---

## ✅ **You're Ready!**

### **Summary:**
1. ✅ Publish via Publish tab (get URL)
2. ✅ Create QR code (qr-code-generator.com)
3. ✅ Add to slides (large and visible)
4. ✅ Create short URL (bit.ly)
5. ✅ Test everything

### **What Your Audience Needs:**
- ✅ Just their phone camera
- ✅ No Genspark account
- ✅ No app downloads
- ✅ No sign-ups
- ✅ Works immediately!

---

## 🎯 **The Impact**

**Instead of just telling people about ROI...**
They **calculate their own** ROI in real-time!

**Instead of passive listening...**
They **actively engage** with your content!

**Instead of forgetting after...**
They have a **tool they can use** anytime!

---

## 📞 **Questions?**

Everything is ready - your calculator is:
- ✅ Mobile-optimized
- ✅ Fast-loading  
- ✅ Professional
- ✅ Ready to share

**Just publish it and create the QR code!**

---

**© 2024 Alexander Scott and Associates**

**Make your presentations interactive and unforgettable! 🚀**