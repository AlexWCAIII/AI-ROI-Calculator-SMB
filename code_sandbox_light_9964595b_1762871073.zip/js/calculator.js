/**
 * AI ROI Calculator - Alexander Scott and Associates
 * Calculate Annual Economic Unit (AEU) and Return on Investment for AI implementations
 */

// Global variables
let roiChart = null;

// Initialize calculator when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners for real-time calculation
    const inputs = ['numEmployees', 'hoursPerDay', 'hourlyWage', 'implementationCost', 'timePeriod'];
    
    inputs.forEach(inputId => {
        const element = document.getElementById(inputId);
        if (element) {
            element.addEventListener('input', calculateROI);
            element.addEventListener('change', calculateROI);
        }
    });

    // Initial calculation with dummy data
    calculateROI();
});

/**
 * Main calculation function
 * Calculates ROI based on productivity gains from AI implementation
 */
function calculateROI() {
    // Get input values
    const numEmployees = parseFloat(document.getElementById('numEmployees').value) || 0;
    const hoursPerDay = parseFloat(document.getElementById('hoursPerDay').value) || 0;
    const hourlyWage = parseFloat(document.getElementById('hourlyWage').value) || 0;
    const implementationCost = parseFloat(document.getElementById('implementationCost').value) || 0;
    const timePeriod = parseFloat(document.getElementById('timePeriod').value) || 1;

    // Validate inputs
    if (numEmployees <= 0 || hoursPerDay <= 0 || hourlyWage <= 0) {
        displayEmptyResults();
        return;
    }

    // Core ROI Calculations
    const calculations = performCalculations(numEmployees, hoursPerDay, hourlyWage, implementationCost, timePeriod);
    
    // Display results
    displayResults(calculations);
    
    // Update chart
    updateROIChart(calculations);

    // Add animation to results
    animateResults();
}

/**
 * Perform all ROI calculations
 */
function performCalculations(numEmployees, hoursPerDay, hourlyWage, implementationCost, timePeriod) {
    // Business days per year (250 working days)
    const businessDaysPerYear = 250;
    
    // Calculate daily savings
    const dailySavings = numEmployees * hoursPerDay * hourlyWage;
    
    // Calculate monthly savings (assume 21 business days per month)
    const monthlySavings = dailySavings * 21;
    
    // Calculate annual savings (AEU - Annual Economic Unit)
    const annualSavings = dailySavings * businessDaysPerYear;
    
    // Calculate total savings over the specified time period
    const totalSavings = annualSavings * timePeriod;
    
    // Calculate net profit after implementation cost
    const netProfit = totalSavings - implementationCost;
    
    // Calculate ROI percentage
    const roiPercentage = implementationCost > 0 ? ((netProfit / implementationCost) * 100) : 0;
    
    // Calculate payback period in months
    const paybackPeriod = implementationCost > 0 && monthlySavings > 0 
        ? implementationCost / monthlySavings 
        : 0;

    return {
        dailySavings,
        monthlySavings,
        annualSavings,
        totalSavings,
        netProfit,
        roiPercentage,
        paybackPeriod,
        implementationCost,
        timePeriod
    };
}

/**
 * Display calculation results in the UI
 */
function displayResults(calc) {
    // Update main result cards
    document.getElementById('annualSavings').textContent = formatCurrency(calc.annualSavings);
    document.getElementById('roiPercentage').textContent = formatPercentage(calc.roiPercentage);
    document.getElementById('paybackPeriod').textContent = formatPaybackPeriod(calc.paybackPeriod);
    
    // Update breakdown section
    document.getElementById('dailySavings').textContent = formatCurrency(calc.dailySavings);
    document.getElementById('monthlySavings').textContent = formatCurrency(calc.monthlySavings);
    document.getElementById('annualSavingsBreakdown').textContent = formatCurrency(calc.annualSavings);
    document.getElementById('totalSavings').textContent = formatCurrency(calc.totalSavings);
    document.getElementById('netProfit').textContent = formatCurrency(calc.netProfit);

    // Update result card styling based on profitability
    updateResultCardStyling(calc.roiPercentage, calc.netProfit);
}

/**
 * Display empty results when inputs are invalid
 */
function displayEmptyResults() {
    const elements = [
        'annualSavings', 'roiPercentage', 'paybackPeriod',
        'dailySavings', 'monthlySavings', 'annualSavingsBreakdown',
        'totalSavings', 'netProfit'
    ];
    
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            if (id === 'roiPercentage') {
                element.textContent = '0%';
            } else if (id === 'paybackPeriod') {
                element.textContent = '0 months';
            } else {
                element.textContent = '$0';
            }
        }
    });

    // Clear chart
    if (roiChart) {
        roiChart.destroy();
        roiChart = null;
    }
}

/**
 * Update result card styling based on profitability
 */
function updateResultCardStyling(roiPercentage, netProfit) {
    const roiElement = document.getElementById('roiPercentage').parentElement;
    const profitElement = document.getElementById('netProfit').parentElement;
    
    // Remove existing styling classes
    roiElement.classList.remove('positive', 'negative');
    
    // Add styling based on profitability
    if (roiPercentage > 0) {
        roiElement.classList.add('positive');
    } else if (roiPercentage < 0) {
        roiElement.classList.add('negative');
    }

    // Style net profit breakdown item
    if (profitElement && profitElement.classList.contains('breakdown-item')) {
        profitElement.classList.remove('positive', 'negative');
        if (netProfit > 0) {
            profitElement.classList.add('positive');
        } else if (netProfit < 0) {
            profitElement.classList.add('negative');
        }
    }
}

/**
 * Create or update the ROI visualization chart
 */
function updateROIChart(calc) {
    const ctx = document.getElementById('roiChart').getContext('2d');
    
    // Destroy existing chart
    if (roiChart) {
        roiChart.destroy();
    }
    
    // Prepare chart data
    const chartData = {
        labels: ['Implementation Cost', 'Annual Savings', 'Net Profit'],
        datasets: [{
            label: 'AI Investment Analysis',
            data: [
                calc.implementationCost,
                calc.annualSavings,
                calc.netProfit
            ],
            backgroundColor: [
                '#dc2626', // Red for cost
                '#2563eb', // Blue for savings
                calc.netProfit >= 0 ? '#059669' : '#dc2626' // Green for positive profit, red for negative
            ],
            borderColor: [
                '#b91c1c',
                '#1d4ed8',
                calc.netProfit >= 0 ? '#047857' : '#b91c1c'
            ],
            borderWidth: 2,
            borderRadius: 8,
            borderSkipped: false
        }]
    };

    // Chart configuration
    const config = {
        type: 'bar',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: `AI ROI Analysis - ${calc.timePeriod} Year${calc.timePeriod > 1 ? 's' : ''}`,
                    font: {
                        size: 16,
                        weight: 'bold'
                    },
                    color: '#1f2937'
                },
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#1f2937',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#2563eb',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += formatCurrency(context.parsed.y);
                            
                            // Add percentage for net profit
                            if (context.label === 'Net Profit' && calc.implementationCost > 0) {
                                const percentage = ((context.parsed.y / calc.implementationCost) * 100).toFixed(1);
                                label += ` (${percentage}% ROI)`;
                            }
                            
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatCurrency(value);
                        },
                        color: '#6b7280'
                    },
                    grid: {
                        color: '#e5e7eb'
                    }
                },
                x: {
                    ticks: {
                        color: '#6b7280',
                        font: {
                            weight: 'bold'
                        }
                    },
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            }
        }
    };

    // Create new chart
    roiChart = new Chart(ctx, config);
}

/**
 * Add animation to results section
 */
function animateResults() {
    const resultsSection = document.querySelector('.calculator-results');
    if (resultsSection) {
        resultsSection.classList.remove('fade-in');
        // Force reflow
        resultsSection.offsetHeight;
        resultsSection.classList.add('fade-in');
    }
}

/**
 * Format currency values
 */
function formatCurrency(value) {
    if (value === 0) return '$0';
    
    const absValue = Math.abs(value);
    const isNegative = value < 0;
    
    let formatted;
    
    if (absValue >= 1000000) {
        formatted = '$' + (absValue / 1000000).toFixed(1) + 'M';
    } else if (absValue >= 1000) {
        formatted = '$' + (absValue / 1000).toFixed(1) + 'K';
    } else {
        formatted = '$' + absValue.toLocaleString(undefined, {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        });
    }
    
    return isNegative ? '-' + formatted : formatted;
}

/**
 * Format percentage values
 */
function formatPercentage(value) {
    if (value === 0) return '0%';
    
    const absValue = Math.abs(value);
    const isNegative = value < 0;
    
    let formatted = absValue.toFixed(1) + '%';
    
    return isNegative ? '-' + formatted : formatted;
}

/**
 * Format payback period
 */
function formatPaybackPeriod(months) {
    if (months === 0) return '0 months';
    if (months === Infinity) return 'Never';
    
    const roundedMonths = Math.round(months);
    
    if (roundedMonths >= 12) {
        const years = Math.floor(roundedMonths / 12);
        const remainingMonths = roundedMonths % 12;
        
        let result = years + ' year' + (years > 1 ? 's' : '');
        if (remainingMonths > 0) {
            result += ', ' + remainingMonths + ' month' + (remainingMonths > 1 ? 's' : '');
        }
        return result;
    } else {
        return roundedMonths + ' month' + (roundedMonths > 1 ? 's' : '');
    }
}

/**
 * Validation helpers
 */
function validateInputs() {
    const inputs = document.querySelectorAll('.input-group input, .input-group select');
    let isValid = true;
    
    inputs.forEach(input => {
        const value = parseFloat(input.value);
        if (input.type === 'number' && (isNaN(value) || value < 0)) {
            input.style.borderColor = '#dc2626';
            isValid = false;
        } else {
            input.style.borderColor = '#e5e7eb';
        }
    });
    
    return isValid;
}

/**
 * Reset calculator to default values
 */
function resetCalculator() {
    document.getElementById('numEmployees').value = 25;
    document.getElementById('hoursPerDay').value = 1.5;
    document.getElementById('hourlyWage').value = 35;
    document.getElementById('implementationCost').value = 15000;
    document.getElementById('timePeriod').value = 3;
    
    calculateROI();
}

/**
 * Export results (future enhancement)
 */
function exportResults() {
    // This could be enhanced to export results as PDF or CSV
    console.log('Export functionality - future enhancement');
}

// Add CSS classes for positive/negative styling
const style = document.createElement('style');
style.textContent = `
    .result-card.positive .result-value {
        color: #059669;
    }
    
    .result-card.negative .result-value {
        color: #dc2626;
    }
    
    .breakdown-item.positive span {
        color: #059669 !important;
    }
    
    .breakdown-item.negative span {
        color: #dc2626 !important;
    }
`;
document.head.appendChild(style);